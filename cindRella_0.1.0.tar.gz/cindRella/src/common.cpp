#include "common.h"
#include <RcppArmadillo.h>
#include <algorithm>
